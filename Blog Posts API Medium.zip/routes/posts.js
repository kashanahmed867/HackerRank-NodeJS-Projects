const express = require('express');
const router = express.Router();
const postsController = require('../controllers/posts');
const Posts = require('../models/posts');

router.post('/', function(req, res){
    Posts.create({
        author: req.body.author,
        title: req.body.title,
        isPublished: req.body.isPublished,
        timestamp: req.body.timestamp,
        publishedDate: req.body.publishedDate,
    }).then(post => {
        /*console.log(book.get({
            plain: true
        }));*/
        res.status(200).json(post);
    }).error(err => {
        res.status(405).json('Error has occured');
    });
});


module.exports = router;
