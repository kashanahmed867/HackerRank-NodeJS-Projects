const { Op } = require('sequelize')
const {subtractSecondsFromCurrentTime} = require('../utils');
// Function subtractSecondsFromCurrentTime is a utility function which accepts the seconds to subtract from thee current time and
// returns the javascript date object
